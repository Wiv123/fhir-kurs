# fhir.education.kursig#0.1.0: Karins test-IG

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [Karins test-IG](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
